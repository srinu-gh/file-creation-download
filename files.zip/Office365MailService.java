package com.example.emailprocessor.service;

import com.example.emailprocessor.config.Office365Properties;
import com.example.emailprocessor.exception.EmailProcessingException;
import com.microsoft.graph.models.Attachment;
import com.microsoft.graph.models.FileAttachment;
import com.microsoft.graph.models.MailFolder;
import com.microsoft.graph.models.Message;
import com.microsoft.graph.options.QueryOption;
import com.microsoft.graph.requests.AttachmentCollectionPage;
import com.microsoft.graph.requests.GraphServiceClient;
import com.microsoft.graph.requests.MessageCollectionPage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Request;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Service responsible for interacting with Office 365 mailbox
 * via Microsoft Graph API to read emails and download attachments.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class Office365MailService {

    private final GraphServiceClient<Request> graphClient;
    private final Office365Properties properties;

    /**
     * Fetches all unread emails with attachments from the configured mail folder.
     *
     * @return list of Message objects that have attachments
     */
    @Retryable(
            retryFor = {EmailProcessingException.class},
            maxAttemptsExpression = "${retry.max-attempts:3}",
            backoff = @Backoff(
                    delayExpression = "${retry.initial-interval-ms:1000}",
                    multiplierExpression = "${retry.multiplier:2.0}",
                    maxDelayExpression = "${retry.max-interval-ms:10000}"
            )
    )
    public List<Message> fetchUnreadEmailsWithAttachments() {
        log.info("Fetching unread emails with attachments from mailbox: {} folder: {}",
                properties.getMailboxUser(), properties.getFolderName());
        try {
            String folderId = resolveMailFolderId(properties.getFolderName());

            MessageCollectionPage messagePage = graphClient
                    .users(properties.getMailboxUser())
                    .mailFolders(folderId)
                    .messages()
                    .buildRequest(List.of(
                            new QueryOption("$filter", "isRead eq false and hasAttachments eq true"),
                            new QueryOption("$select", "id,subject,sender,receivedDateTime,hasAttachments,isRead"),
                            new QueryOption("$orderby", "receivedDateTime asc"),
                            new QueryOption("$top", "50")
                    ))
                    .get();

            List<Message> messages = new ArrayList<>();
            if (messagePage != null && messagePage.getCurrentPage() != null) {
                messages.addAll(messagePage.getCurrentPage());
            }

            log.info("Found {} unread emails with attachments", messages.size());
            return messages;

        } catch (Exception ex) {
            throw new EmailProcessingException(
                    "Failed to fetch emails from Office 365: " + ex.getMessage(), ex);
        }
    }

    /**
     * Fetches full attachment list for a given message.
     */
    @Retryable(
            retryFor = {EmailProcessingException.class},
            maxAttemptsExpression = "${retry.max-attempts:3}",
            backoff = @Backoff(delayExpression = "${retry.initial-interval-ms:1000}")
    )
    public List<FileAttachment> fetchFileAttachments(String messageId) {
        log.debug("Fetching attachments for message ID: {}", messageId);
        try {
            AttachmentCollectionPage attachmentPage = graphClient
                    .users(properties.getMailboxUser())
                    .messages(messageId)
                    .attachments()
                    .buildRequest()
                    .get();

            List<FileAttachment> fileAttachments = new ArrayList<>();
            if (attachmentPage != null && attachmentPage.getCurrentPage() != null) {
                for (Attachment att : attachmentPage.getCurrentPage()) {
                    if (att instanceof FileAttachment fileAtt) {
                        fileAttachments.add(fileAtt);
                    }
                }
            }

            log.debug("Found {} file attachments for message: {}", fileAttachments.size(), messageId);
            return fileAttachments;

        } catch (Exception ex) {
            throw new EmailProcessingException(
                    "Failed to fetch attachments for message " + messageId + ": " + ex.getMessage(), ex);
        }
    }

    /**
     * Marks a message as read after successful processing.
     */
    public void markMessageAsRead(String messageId) {
        try {
            Message updateMessage = new Message();
            updateMessage.isRead = true;

            graphClient
                    .users(properties.getMailboxUser())
                    .messages(messageId)
                    .buildRequest()
                    .patch(updateMessage);

            log.debug("Marked message {} as read", messageId);
        } catch (Exception ex) {
            log.warn("Failed to mark message {} as read: {}", messageId, ex.getMessage());
        }
    }

    /**
     * Moves a processed message to an archive folder.
     */
    public void archiveMessage(String messageId) {
        try {
            String archiveFolderId = resolveOrCreateFolder(properties.getMailboxUser(),
                    "Processed");

            graphClient
                    .users(properties.getMailboxUser())
                    .messages(messageId)
                    .move(archiveFolderId)
                    .buildRequest()
                    .post();

            log.debug("Archived message {} to Processed folder", messageId);
        } catch (Exception ex) {
            log.warn("Failed to archive message {}: {}", messageId, ex.getMessage());
        }
    }

    // ── Private Helpers ──────────────────────────────────────────────────────────

    private String resolveMailFolderId(String folderName) {
        if ("Inbox".equalsIgnoreCase(folderName)) {
            return "Inbox"; // Graph API well-known folder name
        }

        try {
            var folderPage = graphClient
                    .users(properties.getMailboxUser())
                    .mailFolders()
                    .buildRequest(List.of(
                            new QueryOption("$filter", "displayName eq '" + folderName + "'")
                    ))
                    .get();

            Optional<MailFolder> folder = Optional.empty();
            if (folderPage != null && folderPage.getCurrentPage() != null) {
                folder = folderPage.getCurrentPage().stream().findFirst();
            }

            return folder
                    .map(f -> f.id)
                    .orElseThrow(() -> new EmailProcessingException(
                            "Mail folder not found: " + folderName));
        } catch (EmailProcessingException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new EmailProcessingException("Failed to resolve folder: " + folderName, ex);
        }
    }

    private String resolveOrCreateFolder(String userEmail, String folderName) {
        try {
            var folderPage = graphClient
                    .users(userEmail)
                    .mailFolders()
                    .buildRequest(List.of(
                            new QueryOption("$filter", "displayName eq '" + folderName + "'")
                    ))
                    .get();

            if (folderPage != null && folderPage.getCurrentPage() != null
                    && !folderPage.getCurrentPage().isEmpty()) {
                return folderPage.getCurrentPage().get(0).id;
            }

            // Create archive folder if it doesn't exist
            MailFolder newFolder = new MailFolder();
            newFolder.displayName = folderName;

            MailFolder created = graphClient
                    .users(userEmail)
                    .mailFolders()
                    .buildRequest()
                    .post(newFolder);

            log.info("Created mail folder: {}", folderName);
            return created.id;

        } catch (Exception ex) {
            throw new EmailProcessingException("Failed to resolve/create folder: " + folderName, ex);
        }
    }
}
