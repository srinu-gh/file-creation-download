package com.example.emailprocessor.service;

import com.example.emailprocessor.config.SiteUploadProperties;
import com.example.emailprocessor.model.AttachmentUploadDetail;
import com.example.emailprocessor.model.EmailAttachmentResult;
import com.example.emailprocessor.model.ProcessingSummary;
import com.microsoft.graph.models.FileAttachment;
import com.microsoft.graph.models.Message;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Core orchestration service that coordinates:
 * 1. Fetching emails from Office 365
 * 2. Downloading attachments
 * 3. Saving them to the site upload directory
 * 4. Marking / archiving processed emails
 */
@Slf4j
@Service
public class EmailAttachmentProcessorService {

    private final Office365MailService mailService;
    private final FileUploadService fileUploadService;
    private final SiteUploadProperties uploadProperties;

    // Metrics
    private final Counter emailsProcessedCounter;
    private final Counter attachmentsUploadedCounter;
    private final Counter processingErrorsCounter;
    private final Timer processingTimer;

    public EmailAttachmentProcessorService(
            Office365MailService mailService,
            FileUploadService fileUploadService,
            SiteUploadProperties uploadProperties,
            MeterRegistry meterRegistry) {
        this.mailService = mailService;
        this.fileUploadService = fileUploadService;
        this.uploadProperties = uploadProperties;

        // Register Micrometer metrics
        this.emailsProcessedCounter = Counter.builder("email.processor.emails.processed")
                .description("Total number of emails processed")
                .register(meterRegistry);
        this.attachmentsUploadedCounter = Counter.builder("email.processor.attachments.uploaded")
                .description("Total attachments successfully uploaded")
                .register(meterRegistry);
        this.processingErrorsCounter = Counter.builder("email.processor.errors")
                .description("Total processing errors")
                .register(meterRegistry);
        this.processingTimer = Timer.builder("email.processor.duration")
                .description("Time taken for full processing run")
                .register(meterRegistry);
    }

    /**
     * Main entry point — processes all pending emails with attachments.
     *
     * @return a summary of the processing run
     */
    public ProcessingSummary processEmails() {
        return processingTimer.record(() -> {
            Instant startedAt = Instant.now();
            log.info("=== Email attachment processing started at {} ===", startedAt);

            List<EmailAttachmentResult> results = new ArrayList<>();
            int attachmentsUploaded = 0, attachmentsSkipped = 0, attachmentsFailed = 0;

            List<Message> messages;
            try {
                messages = mailService.fetchUnreadEmailsWithAttachments();
            } catch (Exception ex) {
                log.error("Failed to fetch emails, aborting run: {}", ex.getMessage(), ex);
                processingErrorsCounter.increment();
                return buildSummary(startedAt, 0, 0, 0, 1, results);
            }

            for (Message message : messages) {
                EmailAttachmentResult result = processSingleEmail(message);
                results.add(result);

                if (result.getStatus() != EmailAttachmentResult.ProcessingStatus.FAILED) {
                    emailsProcessedCounter.increment();
                }

                if (result.getAttachments() != null) {
                    for (AttachmentUploadDetail detail : result.getAttachments()) {
                        switch (detail.getStatus()) {
                            case UPLOADED -> {
                                attachmentsUploaded++;
                                attachmentsUploadedCounter.increment();
                            }
                            case FAILED -> {
                                attachmentsFailed++;
                                processingErrorsCounter.increment();
                            }
                            default -> attachmentsSkipped++;
                        }
                    }
                }
            }

            ProcessingSummary summary = buildSummary(
                    startedAt, messages.size(),
                    countByStatus(results, EmailAttachmentResult.ProcessingStatus.SUCCESS,
                            EmailAttachmentResult.ProcessingStatus.PARTIAL_SUCCESS),
                    countByStatus(results, EmailAttachmentResult.ProcessingStatus.FAILED),
                    countByStatus(results, EmailAttachmentResult.ProcessingStatus.SKIPPED),
                    results
            );
            summary.setTotalAttachmentsUploaded(attachmentsUploaded);
            summary.setTotalAttachmentsSkipped(attachmentsSkipped);
            summary.setTotalAttachmentsFailed(attachmentsFailed);

            log.info("=== Processing completed in {}ms | Emails: {}/{} | Attachments uploaded: {} ===",
                    summary.getDurationMs(), summary.getEmailsProcessed(),
                    summary.getTotalEmailsFound(), attachmentsUploaded);

            return summary;
        });
    }

    // ── Private Methods ──────────────────────────────────────────────────────────

    private EmailAttachmentResult processSingleEmail(Message message) {
        String subject = message.subject != null ? message.subject : "(no subject)";
        String sender = message.sender != null && message.sender.emailAddress != null
                ? message.sender.emailAddress.address : "unknown";

        log.info("Processing email: '{}' from: {}", subject, sender);

        List<AttachmentUploadDetail> uploadDetails = new ArrayList<>();

        try {
            List<FileAttachment> attachments = mailService.fetchFileAttachments(message.id);

            if (attachments.isEmpty()) {
                log.info("No file attachments found in email: {}", subject);
                return EmailAttachmentResult.builder()
                        .emailId(message.id)
                        .emailSubject(subject)
                        .senderAddress(sender)
                        .receivedDateTime(message.receivedDateTime)
                        .attachments(uploadDetails)
                        .status(EmailAttachmentResult.ProcessingStatus.SKIPPED)
                        .build();
            }

            for (FileAttachment attachment : attachments) {
                AttachmentUploadDetail detail = fileUploadService.saveAttachment(attachment);
                uploadDetails.add(detail);
                log.debug("Attachment '{}' -> status: {}, path: {}",
                        detail.getOriginalFileName(), detail.getStatus(), detail.getSavedFilePath());
            }

            // Post-processing: mark as read and optionally archive
            mailService.markMessageAsRead(message.id);
            if (uploadProperties.isArchiveProcessedEmails()) {
                mailService.archiveMessage(message.id);
            }

            boolean anyFailed = uploadDetails.stream()
                    .anyMatch(d -> d.getStatus() == AttachmentUploadDetail.UploadStatus.FAILED);
            boolean anyUploaded = uploadDetails.stream()
                    .anyMatch(d -> d.getStatus() == AttachmentUploadDetail.UploadStatus.UPLOADED);

            EmailAttachmentResult.ProcessingStatus status;
            if (anyFailed && anyUploaded) {
                status = EmailAttachmentResult.ProcessingStatus.PARTIAL_SUCCESS;
            } else if (anyFailed) {
                status = EmailAttachmentResult.ProcessingStatus.FAILED;
            } else {
                status = EmailAttachmentResult.ProcessingStatus.SUCCESS;
            }

            return EmailAttachmentResult.builder()
                    .emailId(message.id)
                    .emailSubject(subject)
                    .senderAddress(sender)
                    .receivedDateTime(message.receivedDateTime)
                    .attachments(uploadDetails)
                    .status(status)
                    .build();

        } catch (Exception ex) {
            log.error("Failed to process email '{}': {}", subject, ex.getMessage(), ex);
            return EmailAttachmentResult.builder()
                    .emailId(message.id)
                    .emailSubject(subject)
                    .senderAddress(sender)
                    .receivedDateTime(message.receivedDateTime)
                    .attachments(uploadDetails)
                    .status(EmailAttachmentResult.ProcessingStatus.FAILED)
                    .errorMessage(ex.getMessage())
                    .build();
        }
    }

    private ProcessingSummary buildSummary(Instant startedAt, int total,
                                            int processed, int failed, int skipped,
                                            List<EmailAttachmentResult> results) {
        return ProcessingSummary.builder()
                .startedAt(startedAt)
                .completedAt(Instant.now())
                .totalEmailsFound(total)
                .emailsProcessed(processed)
                .emailsFailed(failed)
                .emailsSkipped(skipped)
                .results(results)
                .build();
    }

    @SafeVarargs
    private <T extends Enum<T>> int countByStatus(List<EmailAttachmentResult> results,
                                                   EmailAttachmentResult.ProcessingStatus... statuses) {
        int count = 0;
        for (EmailAttachmentResult r : results) {
            for (EmailAttachmentResult.ProcessingStatus s : statuses) {
                if (r.getStatus() == s) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }
}
