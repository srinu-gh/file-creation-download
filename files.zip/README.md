# Email Attachment Processor

A production-ready Spring Boot application that polls an **Office 365 mailbox** via the **Microsoft Graph API**, downloads text file attachments, and saves them to a configurable **site upload directory**.

---

## Architecture

```
Office 365 Mailbox
       │  Microsoft Graph API (OAuth2 Client Credentials)
       ▼
EmailPollingScheduler  ──► EmailAttachmentProcessorService
                                    │
                    ┌───────────────┴──────────────────┐
                    ▼                                  ▼
         Office365MailService               FileUploadService
         (fetch / archive emails)           (validate & save files)
                    │                                  │
                    ▼                                  ▼
           Office 365 Mailbox              /var/data/uploads/YYYY/MM/DD/
```

---

## Azure AD Setup

1. Go to **Azure Portal → Azure Active Directory → App registrations → New registration**
2. Add **API permissions** (Application, not Delegated):
   - `Microsoft Graph → Mail.Read`
   - `Microsoft Graph → Mail.ReadWrite`
3. **Grant admin consent**
4. Create a **Client Secret** under *Certificates & secrets*
5. Note your **Tenant ID**, **Client ID**, and **Client Secret**

---

## Configuration

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
```

| Variable | Description | Default |
|---|---|---|
| `OFFICE365_TENANT_ID` | Azure AD Tenant ID | **required** |
| `OFFICE365_CLIENT_ID` | App Registration Client ID | **required** |
| `OFFICE365_CLIENT_SECRET` | App Registration Client Secret | **required** |
| `OFFICE365_MAILBOX_USER` | Mailbox to monitor (e.g. `reports@co.com`) | **required** |
| `OFFICE365_FOLDER_NAME` | Folder to poll | `Inbox` |
| `SITE_UPLOAD_BASE_PATH` | Root directory for saved files | **required** |
| `ALLOWED_EXTENSIONS` | Comma-separated allowed extensions | `.txt,.csv,.log` |
| `MAX_ATTACHMENT_SIZE_MB` | Max attachment size in MB | `10` |
| `EMAIL_POLL_CRON` | Spring cron expression for polling | `0 */5 * * * *` |
| `ARCHIVE_EMAILS` | Move processed emails to Processed folder | `true` |

---

## Running

### Local (Maven)
```bash
export $(cat .env | xargs)
./mvnw spring-boot:run
```

### Docker Compose
```bash
docker-compose up -d
docker-compose logs -f
```

---

## API Endpoints

| Method | Path | Description |
|---|---|---|
| `POST` | `/api/email-processor/trigger` | Manually trigger a processing run |
| `GET` | `/api/email-processor/status` | Basic status check |
| `GET` | `/api/actuator/health` | Spring Boot health |
| `GET` | `/api/actuator/metrics` | Micrometer metrics |
| `GET` | `/api/actuator/prometheus` | Prometheus scrape endpoint |

### Manual trigger example
```bash
curl -X POST http://localhost:8080/api/email-processor/trigger | jq
```

---

## Key Features

- **Microsoft Graph API** — modern, secure OAuth2 app-only authentication
- **Configurable polling** — cron-based scheduler with overlap protection
- **File validation** — extension allowlist + max size enforcement
- **Path traversal protection** — sanitizes all file names before writing
- **Retry with exponential backoff** — via Spring Retry on Graph API calls
- **Email archiving** — moves processed emails to a *Processed* folder
- **Date-based subdirectories** — organizes files as `YYYY/MM/DD/`
- **Micrometer metrics** — counters and timers exposed via Prometheus
- **Structured logging** — JSON-friendly log pattern with rolling file
- **Docker-ready** — multi-stage Dockerfile, non-root user, health check

---

## Running Tests

```bash
./mvnw test
```
