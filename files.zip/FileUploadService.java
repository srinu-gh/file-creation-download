package com.example.emailprocessor.service;

import com.example.emailprocessor.config.Office365Properties;
import com.example.emailprocessor.config.SiteUploadProperties;
import com.example.emailprocessor.exception.FileUploadException;
import com.example.emailprocessor.model.AttachmentUploadDetail;
import com.microsoft.graph.models.FileAttachment;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Service responsible for saving downloaded attachment bytes
 * to the configured site upload location.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FileUploadService {

    private static final DateTimeFormatter DATE_PATH_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy/MM/dd");
    private static final long BYTES_PER_MB = 1024L * 1024L;

    private final SiteUploadProperties uploadProperties;
    private final Office365Properties office365Properties;

    /**
     * Saves a file attachment to the site upload directory.
     *
     * @param attachment the FileAttachment from Graph API
     * @return AttachmentUploadDetail describing the result
     */
    public AttachmentUploadDetail saveAttachment(FileAttachment attachment) {
        String fileName = attachment.name;
        byte[] content = attachment.contentBytes;
        long sizeBytes = (content != null) ? content.length : 0L;

        log.debug("Processing attachment: {} ({} bytes)", fileName, sizeBytes);

        // Validate extension
        if (!isExtensionAllowed(fileName)) {
            log.info("Skipping attachment '{}' — extension not in allowed list", fileName);
            return buildSkippedResult(attachment, AttachmentUploadDetail.UploadStatus.SKIPPED_EXTENSION,
                    "Extension not in allowed list");
        }

        // Validate size
        long maxBytes = (long) office365Properties.getAttachment().getMaxSizeMb() * BYTES_PER_MB;
        if (sizeBytes > maxBytes) {
            log.warn("Skipping attachment '{}' — size {} bytes exceeds limit {} bytes",
                    fileName, sizeBytes, maxBytes);
            return buildSkippedResult(attachment, AttachmentUploadDetail.UploadStatus.SKIPPED_SIZE,
                    "File size exceeds limit of " + office365Properties.getAttachment().getMaxSizeMb() + " MB");
        }

        try {
            Path targetDir = resolveTargetDirectory();
            Path targetFile = targetDir.resolve(sanitizeFileName(fileName));

            // Handle existing file
            if (Files.exists(targetFile)) {
                if (!uploadProperties.isOverwriteExisting()) {
                    log.info("Skipping '{}' — file already exists at: {}", fileName, targetFile);
                    return buildSkippedResult(attachment, AttachmentUploadDetail.UploadStatus.SKIPPED_EXISTS,
                            "File already exists: " + targetFile);
                }
                log.info("Overwriting existing file: {}", targetFile);
            }

            // Write file
            Files.write(targetFile, content,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);

            log.info("Successfully saved attachment '{}' to: {}", fileName, targetFile);

            return AttachmentUploadDetail.builder()
                    .attachmentId(attachment.id)
                    .originalFileName(fileName)
                    .savedFilePath(targetFile.toAbsolutePath().toString())
                    .fileSizeBytes(sizeBytes)
                    .savedAt(Instant.now())
                    .status(AttachmentUploadDetail.UploadStatus.UPLOADED)
                    .build();

        } catch (IOException ex) {
            String errMsg = "IO error saving attachment '" + fileName + "': " + ex.getMessage();
            log.error(errMsg, ex);
            return AttachmentUploadDetail.builder()
                    .attachmentId(attachment.id)
                    .originalFileName(fileName)
                    .fileSizeBytes(sizeBytes)
                    .savedAt(Instant.now())
                    .status(AttachmentUploadDetail.UploadStatus.FAILED)
                    .errorMessage(errMsg)
                    .build();
        }
    }

    /**
     * Ensures the target upload directory exists, creating it if necessary.
     */
    public void initializeUploadDirectory() {
        try {
            Path basePath = Paths.get(uploadProperties.getBasePath());
            Files.createDirectories(basePath);
            log.info("Upload directory initialized: {}", basePath.toAbsolutePath());
        } catch (IOException ex) {
            throw new FileUploadException(
                    "Cannot initialize upload directory: " + uploadProperties.getBasePath(), ex);
        }
    }

    // ── Private Helpers ──────────────────────────────────────────────────────────

    private Path resolveTargetDirectory() throws IOException {
        Path base = Paths.get(uploadProperties.getBasePath());

        if (uploadProperties.isCreateDateSubdirs()) {
            String datePath = LocalDate.now().format(DATE_PATH_FORMATTER);
            base = base.resolve(datePath);
        }

        Files.createDirectories(base);
        return base;
    }

    private boolean isExtensionAllowed(String fileName) {
        if (fileName == null || fileName.isBlank()) return false;
        String lower = fileName.toLowerCase();
        return office365Properties.getAttachment().getAllowedExtensions()
                .stream()
                .anyMatch(lower::endsWith);
    }

    /**
     * Sanitizes the file name to prevent path traversal attacks.
     */
    private String sanitizeFileName(String fileName) {
        // Strip any directory components
        String sanitized = Paths.get(fileName).getFileName().toString();
        // Replace any remaining unsafe characters
        sanitized = sanitized.replaceAll("[^a-zA-Z0-9._\\-]", "_");
        return sanitized;
    }

    private AttachmentUploadDetail buildSkippedResult(FileAttachment att,
                                                       AttachmentUploadDetail.UploadStatus status,
                                                       String reason) {
        return AttachmentUploadDetail.builder()
                .attachmentId(att.id)
                .originalFileName(att.name)
                .fileSizeBytes(att.contentBytes != null ? att.contentBytes.length : 0L)
                .savedAt(Instant.now())
                .status(status)
                .errorMessage(reason)
                .build();
    }
}
